import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'node:path';

export default defineConfig({
  plugins: [react()],
  base: '/Noted/',
  build: {
    rollupOptions: {
      input: {
        home: resolve(import.meta.dirname, 'index.html'),
        mui: resolve(import.meta.dirname, 'mui/index.html'),
        material3: resolve(import.meta.dirname, 'material3/index.html'),
      },
    },
  },
});
