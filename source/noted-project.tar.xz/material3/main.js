import '@material/web/all.js';
import { styles as typescaleStyles } from '@material/web/typography/md-typescale-styles.js';
import './style.css';

document.adoptedStyleSheets.push(typescaleStyles.styleSheet);

const STORAGE_KEY = 'noted.material3.notes.v1';
const colors = [
  { label: 'Default', value: '#ffffff' },
  { label: 'Cream', value: '#fff8e8' },
  { label: 'Rose', value: '#fff0f1' },
  { label: 'Sage', value: '#edf6ef' },
  { label: 'Sky', value: '#edf5ff' },
  { label: 'Lilac', value: '#f3efff' },
];
const nav = [
  { id: 'notes', label: 'All notes', icon: 'description' },
  { id: 'pinned', label: 'Pinned', icon: 'push_pin' },
  { id: 'archived', label: 'Archive', icon: 'archive' },
  { id: 'trash', label: 'Trash', icon: 'delete' },
];

function readNotes() {
  try {
    const notes = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(notes) ? notes : [];
  } catch { return []; }
}
function makeId() { return globalThis.crypto?.randomUUID?.() || `note-${Date.now()}-${Math.random()}`; }
function escapeHtml(value = '') {
  return String(value).replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}
function formatDate(value) {
  if (!value) return 'Just now';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Recently edited';
  return date.toDateString() === new Date().toDateString()
    ? `Edited ${date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`
    : `Edited ${date.toLocaleDateString([], { month: 'short', day: 'numeric' })}`;
}

const root = document.querySelector('#app');
root.innerHTML = `
  <div class="app-shell">
    <aside class="sidebar">
      <a class="brand" href="../"><span class="brand-icon"><md-icon>edit_note</md-icon></span><span>noted</span></a>
      <md-filled-button id="new-note" class="new-note"><md-icon slot="icon">add</md-icon>New note</md-filled-button>
      <div class="nav-label">WORKSPACE</div>
      <nav id="navigation" aria-label="Notes navigation"></nav>
      <div class="sidebar-bottom"><div class="storage-icon"><md-icon>lightbulb</md-icon></div><div><strong>Saved on this device</strong><span>Private browser storage</span></div></div>
    </aside>
    <main class="main-area">
      <header class="topbar"><div class="breadcrumb"><span>Your workspace</span><span>/</span><strong id="crumb">All notes</strong></div><div class="top-actions"><a class="versions-link" href="../"><md-icon>apps</md-icon>Design versions</a><span class="saved"><i></i>All changes saved</span></div></header>
      <section class="page-content"><div class="page-heading"><div><div class="eyebrow">YOUR WORKSPACE</div><h1 id="page-title">All notes</h1><p id="page-subtitle">A little space for everything on your mind.</p></div><md-filled-button id="create-note"><md-icon slot="icon">add</md-icon>Create note</md-filled-button></div>
        <div id="section-label" class="section-label" hidden><md-icon>push_pin</md-icon>PINNED NOTES</div>
        <div id="notes-grid" class="notes-grid"></div>
      </section>
    </main>
  </div>
  <dialog id="editor" class="editor-dialog">
    <form method="dialog" id="editor-form">
      <div class="dialog-heading"><div><div class="dialog-eyebrow">YOUR NOTE</div><h2 id="dialog-title">New note</h2></div><md-icon-button id="close-editor" aria-label="Close"><md-icon>close</md-icon></md-icon-button></div>
      <div class="editor-fields"><md-outlined-text-field id="note-title" label="Title" placeholder="Give your note a title" maxlength="140"></md-outlined-text-field><label class="body-label" for="note-body">NOTE</label><textarea id="note-body" rows="9" placeholder="Start writing..."></textarea>
        <div class="color-picker"><span>NOTE COLOR</span><div id="color-options"></div></div>
      </div>
      <div class="dialog-actions"><md-text-button id="cancel-editor">Cancel</md-text-button><md-filled-button id="save-note">Save note</md-filled-button></div>
    </form>
  </dialog>
  <dialog id="delete-dialog" class="confirm-dialog"><form method="dialog"><h2>Delete this note permanently?</h2><p>This note will be removed from this browser and cannot be restored.</p><div class="dialog-actions"><md-text-button id="cancel-delete">Cancel</md-text-button><md-filled-button id="confirm-delete">Delete permanently</md-filled-button></div></form></dialog>
  <div id="snackbar" class="snackbar" role="status" aria-live="polite"></div>
`;

let notes = readNotes();
let view = 'notes';
let editingId = null;
let draftColor = colors[0].value;
let deleteTarget = null;
let snackbarTimer;
const editor = root.querySelector('#editor');
const deleteDialog = root.querySelector('#delete-dialog');
const titleField = root.querySelector('#note-title');
const bodyField = root.querySelector('#note-body');

function persist() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(notes)); }
  catch { showMessage('Browser storage is full. Some changes may not be saved.'); }
}
function showMessage(message) {
  const snackbar = root.querySelector('#snackbar');
  snackbar.textContent = message;
  snackbar.classList.add('visible');
  clearTimeout(snackbarTimer);
  snackbarTimer = setTimeout(() => snackbar.classList.remove('visible'), 2600);
}
function count(id) {
  if (id === 'notes') return notes.filter((note) => !note.archived && !note.trashed).length;
  if (id === 'pinned') return notes.filter((note) => note.pinned && !note.archived && !note.trashed).length;
  if (id === 'archived') return notes.filter((note) => note.archived && !note.trashed).length;
  return notes.filter((note) => note.trashed).length;
}
function renderNavigation() {
  root.querySelector('#navigation').innerHTML = nav.map((item) => `
    <button class="nav-item ${view === item.id ? 'selected' : ''}" data-view="${item.id}">
      <md-icon>${item.icon}</md-icon><span>${item.label}</span>${count(item.id) ? `<span class="nav-count">${count(item.id)}</span>` : ''}
    </button>`).join('');
  root.querySelectorAll('[data-view]').forEach((button) => button.addEventListener('click', () => { view = button.dataset.view; render(); }));
}
function visibleNotes() {
  const filtered = notes.filter((note) => {
    if (view === 'pinned') return note.pinned && !note.archived && !note.trashed;
    if (view === 'archived') return note.archived && !note.trashed;
    if (view === 'trash') return note.trashed;
    return !note.archived && !note.trashed;
  });
  return filtered.sort((a, b) => view === 'trash'
    ? new Date(b.trashedAt || b.updatedAt) - new Date(a.trashedAt || a.updatedAt)
    : (view === 'notes' && a.pinned !== b.pinned ? (a.pinned ? -1 : 1) : new Date(b.updatedAt) - new Date(a.updatedAt)));
}
function render() {
  renderNavigation();
  const heading = { notes: ['All notes', 'A little space for everything on your mind.'], pinned: ['Pinned', 'The notes you want to keep close.'], archived: ['Archive', 'Notes tucked away for later.'], trash: ['Trash', 'Deleted notes stay here until you remove them for good.'] }[view];
  root.querySelector('#crumb').textContent = heading[0];
  root.querySelector('#page-title').textContent = heading[0];
  root.querySelector('#page-subtitle').textContent = heading[1];
  root.querySelector('#create-note').hidden = view === 'trash';
  const list = visibleNotes();
  root.querySelector('#section-label').hidden = !(view === 'notes' && count('pinned'));
  const grid = root.querySelector('#notes-grid');
  if (!list.length) {
    const title = { notes: 'Your notes start here', pinned: 'No pinned notes', archived: 'No archived notes yet', trash: 'Nothing in the trash' }[view];
    const description = { notes: 'Capture an idea, make a list, or write down whatever is on your mind.', pinned: 'Pin important notes and they will be collected in one place.', archived: 'Archive notes you want to keep but do not need right now.', trash: 'Notes you delete will show up here.' }[view];
    grid.innerHTML = `<div class="empty-state"><div class="empty-icon"><md-icon>${view === 'trash' ? 'delete' : view === 'archived' ? 'archive' : 'edit_note'}</md-icon></div><h2>${title}</h2><p>${description}</p>${view === 'notes' ? '<md-outlined-button id="empty-create"><md-icon slot="icon">add</md-icon>Create your first note</md-outlined-button>' : '<md-text-button id="back-notes">Back to all notes</md-text-button>'}</div>`;
    root.querySelector('#empty-create')?.addEventListener('click', openNewNote);
    root.querySelector('#back-notes')?.addEventListener('click', () => { view = 'notes'; render(); });
    return;
  }
  grid.innerHTML = list.map((note) => `
    <article class="note-card" data-note="${escapeHtml(note.id)}" style="--note-color:${escapeHtml(note.color || '#ffffff')}">
      <button class="note-open" data-edit="${escapeHtml(note.id)}" ${view === 'trash' ? 'disabled' : ''}>
        <span class="note-head"><strong>${escapeHtml(note.title || 'Untitled note')}</strong>${note.pinned && !note.archived && !note.trashed ? '<md-icon class="pinned-mark">push_pin</md-icon>' : ''}</span>
        <span class="note-preview">${escapeHtml(note.body || 'No additional text')}</span>
      </button>
      <footer class="note-footer"><span>${formatDate(note.updatedAt)}</span><span class="note-actions">${view === 'trash'
        ? `<md-icon-button data-restore="${escapeHtml(note.id)}" aria-label="Restore note"><md-icon>restore_from_trash</md-icon></md-icon-button><md-icon-button data-delete="${escapeHtml(note.id)}" aria-label="Delete permanently"><md-icon>delete_forever</md-icon></md-icon-button>`
        : view === 'archived'
          ? `<md-icon-button data-unarchive="${escapeHtml(note.id)}" aria-label="Unarchive"><md-icon>unarchive</md-icon></md-icon-button><md-icon-button data-trash="${escapeHtml(note.id)}" aria-label="Move to trash"><md-icon>delete</md-icon></md-icon-button>`
          : `<md-icon-button data-pin="${escapeHtml(note.id)}" aria-label="${note.pinned ? 'Unpin' : 'Pin'}"><md-icon>${note.pinned ? 'keep_off' : 'push_pin'}</md-icon></md-icon-button><md-icon-button data-archive="${escapeHtml(note.id)}" aria-label="Archive"><md-icon>archive</md-icon></md-icon-button><md-icon-button data-trash="${escapeHtml(note.id)}" aria-label="Move to trash"><md-icon>delete</md-icon></md-icon-button>`}</span></footer>
    </article>`).join('');
  root.querySelectorAll('[data-edit]').forEach((button) => button.addEventListener('click', () => editNote(button.dataset.edit)));
  root.querySelectorAll('[data-pin]').forEach((button) => button.addEventListener('click', () => updateNote(button.dataset.pin, { pinned: !notes.find((n) => n.id === button.dataset.pin).pinned })));
  root.querySelectorAll('[data-archive]').forEach((button) => button.addEventListener('click', () => { updateNote(button.dataset.archive, { archived: true, pinned: false }); showMessage('Note archived'); }));
  root.querySelectorAll('[data-unarchive]').forEach((button) => button.addEventListener('click', () => updateNote(button.dataset.unarchive, { archived: false })));
  root.querySelectorAll('[data-trash]').forEach((button) => button.addEventListener('click', () => { updateNote(button.dataset.trash, { trashed: true, trashedAt: new Date().toISOString(), archived: false }); showMessage('Moved to trash'); }));
  root.querySelectorAll('[data-restore]').forEach((button) => button.addEventListener('click', () => { updateNote(button.dataset.restore, { trashed: false, trashedAt: null }); showMessage('Note restored'); }));
  root.querySelectorAll('[data-delete]').forEach((button) => button.addEventListener('click', () => openDelete(button.dataset.delete)));
}
function updateNote(id, updates) {
  notes = notes.map((note) => note.id === id ? { ...note, ...updates, updatedAt: new Date().toISOString() } : note);
  persist(); render();
}
function openNewNote() {
  editingId = null; draftColor = colors[0].value;
  root.querySelector('#dialog-title').textContent = 'New note';
  titleField.value = ''; bodyField.value = '';
  renderColorPicker(); editor.showModal();
  setTimeout(() => titleField.focus(), 50);
}
function editNote(id) {
  const note = notes.find((item) => item.id === id);
  if (!note || note.trashed) return;
  editingId = id; draftColor = note.color || colors[0].value;
  root.querySelector('#dialog-title').textContent = 'Edit note';
  titleField.value = note.title || ''; bodyField.value = note.body || '';
  renderColorPicker(); editor.showModal();
  setTimeout(() => titleField.focus(), 50);
}
function renderColorPicker() {
  root.querySelector('#color-options').innerHTML = colors.map((color) => `<button type="button" class="swatch ${draftColor === color.value ? 'active' : ''}" title="${color.label}" aria-label="${color.label}" data-color="${color.value}" style="--swatch:${color.value}">${draftColor === color.value ? '<md-icon>check</md-icon>' : ''}</button>`).join('');
  root.querySelectorAll('[data-color]').forEach((button) => button.addEventListener('click', () => { draftColor = button.dataset.color; renderColorPicker(); }));
}
function saveNote(event) {
  event?.preventDefault();
  const title = titleField.value.trim(); const body = bodyField.value.trim();
  if (!title && !body) { editor.close(); return; }
  const now = new Date().toISOString();
  if (editingId) {
    notes = notes.map((note) => note.id === editingId ? { ...note, title, body, color: draftColor, updatedAt: now } : note);
    showMessage('Note updated');
  } else {
    notes.unshift({ id: makeId(), title, body, color: draftColor, pinned: false, archived: false, trashed: false, createdAt: now, updatedAt: now });
    showMessage('Note created');
  }
  persist(); editor.close(); view = 'notes'; render();
}
function openDelete(id) { deleteTarget = id; deleteDialog.showModal(); }
function permanentlyDelete() {
  if (!deleteTarget) return;
  notes = notes.filter((note) => note.id !== deleteTarget);
  deleteTarget = null; persist(); deleteDialog.close(); render(); showMessage('Note permanently deleted');
}

root.querySelector('#new-note').addEventListener('click', openNewNote);
root.querySelector('#create-note').addEventListener('click', openNewNote);
root.querySelector('#close-editor').addEventListener('click', () => editor.close());
root.querySelector('#cancel-editor').addEventListener('click', () => editor.close());
root.querySelector('#save-note').addEventListener('click', saveNote);
root.querySelector('#editor-form').addEventListener('submit', saveNote);
root.querySelector('#cancel-delete').addEventListener('click', () => deleteDialog.close());
root.querySelector('#confirm-delete').addEventListener('click', permanentlyDelete);
render();
