import { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  Box,
  Button,
  Card,
  CardActionArea,
  CardActions,
  CardContent,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Drawer,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Snackbar,
  Stack,
  TextField,
  Tooltip,
  Typography,
  useMediaQuery,
} from '@mui/material';
import { useTheme } from '@mui/material/styles';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import ArchiveOutlinedIcon from '@mui/icons-material/ArchiveOutlined';
import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import EditNoteRoundedIcon from '@mui/icons-material/EditNoteRounded';
import Inventory2OutlinedIcon from '@mui/icons-material/Inventory2Outlined';
import MenuRoundedIcon from '@mui/icons-material/MenuRounded';
import PushPinOutlinedIcon from '@mui/icons-material/PushPinOutlined';
import PushPinRoundedIcon from '@mui/icons-material/PushPinRounded';
import RestoreFromTrashOutlinedIcon from '@mui/icons-material/RestoreFromTrashOutlined';
import StickyNote2OutlinedIcon from '@mui/icons-material/StickyNote2Outlined';
import UnarchiveOutlinedIcon from '@mui/icons-material/UnarchiveOutlined';
import DeleteForeverOutlinedIcon from '@mui/icons-material/DeleteForeverOutlined';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import LightbulbOutlinedIcon from '@mui/icons-material/LightbulbOutlined';
import AppsRoundedIcon from '@mui/icons-material/AppsRounded';

const STORAGE_KEY = 'noted.mui.notes.v1';
const DRAWER_WIDTH = 256;

const NOTE_COLORS = [
  { name: 'Default', value: '#ffffff' },
  { name: 'Cream', value: '#fff8e8' },
  { name: 'Rose', value: '#fff0f1' },
  { name: 'Sage', value: '#edf6ef' },
  { name: 'Sky', value: '#edf5ff' },
  { name: 'Lilac', value: '#f3efff' },
];

const NAV_ITEMS = [
  { id: 'notes', label: 'All notes', icon: StickyNote2OutlinedIcon },
  { id: 'pinned', label: 'Pinned', icon: PushPinOutlinedIcon },
  { id: 'archived', label: 'Archive', icon: Inventory2OutlinedIcon },
  { id: 'trash', label: 'Trash', icon: DeleteOutlineRoundedIcon },
];

function readNotes() {
  try {
    const stored = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
    return Array.isArray(stored) ? stored : [];
  } catch {
    return [];
  }
}

function makeId() {
  return globalThis.crypto?.randomUUID?.() || `note-${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function formatDate(value) {
  if (!value) return 'Just now';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return 'Recently edited';
  const now = new Date();
  const sameDay = date.toDateString() === now.toDateString();
  return sameDay
    ? `Edited ${date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`
    : `Edited ${date.toLocaleDateString([], { month: 'short', day: 'numeric' })}`;
}

function App() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [notes, setNotes] = useState(readNotes);
  const [view, setView] = useState('notes');
  const [editorOpen, setEditorOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [draftTitle, setDraftTitle] = useState('');
  const [draftBody, setDraftBody] = useState('');
  const [draftColor, setDraftColor] = useState('#ffffff');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [snackbar, setSnackbar] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
    } catch {
      setSnackbar('Your browser storage is full. Some changes may not be saved.');
    }
  }, [notes]);

  const counts = useMemo(() => ({
    notes: notes.filter((note) => !note.archived && !note.trashed).length,
    pinned: notes.filter((note) => note.pinned && !note.archived && !note.trashed).length,
    archived: notes.filter((note) => note.archived && !note.trashed).length,
    trash: notes.filter((note) => note.trashed).length,
  }), [notes]);

  const visibleNotes = useMemo(() => {
    let result = notes.filter((note) => {
      if (view === 'pinned') return note.pinned && !note.archived && !note.trashed;
      if (view === 'archived') return note.archived && !note.trashed;
      if (view === 'trash') return note.trashed;
      return !note.archived && !note.trashed;
    });
    result = [...result].sort((a, b) => {
      if (view === 'trash') return new Date(b.trashedAt || b.updatedAt) - new Date(a.trashedAt || a.updatedAt);
      if (view === 'notes' && a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return new Date(b.updatedAt) - new Date(a.updatedAt);
    });
    return result;
  }, [notes, view]);

  const currentNav = NAV_ITEMS.find((item) => item.id === view) || NAV_ITEMS[0];

  function openNewNote() {
    setEditingId(null);
    setDraftTitle('');
    setDraftBody('');
    setDraftColor('#ffffff');
    setEditorOpen(true);
  }

  function openEditNote(note) {
    if (view === 'trash') return;
    setEditingId(note.id);
    setDraftTitle(note.title || '');
    setDraftBody(note.body || '');
    setDraftColor(note.color || '#ffffff');
    setEditorOpen(true);
  }

  function saveNote() {
    const title = draftTitle.trim();
    const body = draftBody.trim();
    if (!title && !body) {
      setEditorOpen(false);
      return;
    }
    const now = new Date().toISOString();
    if (editingId) {
      setNotes((current) => current.map((note) => note.id === editingId
        ? { ...note, title, body, color: draftColor, updatedAt: now }
        : note));
      setSnackbar('Note updated');
    } else {
      setNotes((current) => [{
        id: makeId(), title, body, color: draftColor,
        pinned: false, archived: false, trashed: false,
        createdAt: now, updatedAt: now,
      }, ...current]);
      setSnackbar('Note created');
    }
    setEditorOpen(false);
  }

  function updateNote(id, updates) {
    const now = new Date().toISOString();
    setNotes((current) => current.map((note) => note.id === id
      ? { ...note, ...updates, updatedAt: now }
      : note));
  }

  function moveToTrash(note) {
    updateNote(note.id, { trashed: true, trashedAt: new Date().toISOString(), archived: false });
    setSnackbar('Moved to trash');
  }

  function restoreNote(note) {
    updateNote(note.id, { trashed: false, trashedAt: null });
    setSnackbar('Note restored');
  }

  function permanentlyDelete() {
    if (!deleteTarget) return;
    setNotes((current) => current.filter((item) => item.id !== deleteTarget.id));
    setDeleteTarget(null);
    setSnackbar('Note permanently deleted');
  }

  function handleNavClick(nextView) {
    setView(nextView);
    setMobileNavOpen(false);
  }

  function handleCardAction(event, action) {
    event.stopPropagation();
    action();
  }

  const titleByView = {
    notes: 'All notes', pinned: 'Pinned', archived: 'Archive', trash: 'Trash',
  };
  const subtitleByView = {
    notes: 'A little space for everything on your mind.',
    pinned: 'The notes you want to keep close.',
    archived: 'Notes tucked away for later.',
    trash: 'Deleted notes stay here until you remove them for good.',
  };

  const sidebar = (
    <Box className="sidebar-content">
      <Box className="brand-row">
        <Box className="brand-mark"><EditNoteRoundedIcon sx={{ fontSize: 25 }} /></Box>
        <Typography variant="h6" sx={{ fontWeight: 700, letterSpacing: '-0.04em' }}>noted</Typography>
      </Box>
      <Button
        fullWidth
        variant="contained"
        startIcon={<AddRoundedIcon />}
        onClick={openNewNote}
        className="new-note-button"
      >
        New note
      </Button>
      <Typography className="nav-caption">WORKSPACE</Typography>
      <List disablePadding className="navigation-list">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const selected = view === item.id;
          return (
            <ListItemButton
              key={item.id}
              selected={selected}
              onClick={() => handleNavClick(item.id)}
              className="nav-item"
            >
              <ListItemIcon className="nav-icon"><Icon fontSize="small" /></ListItemIcon>
              <ListItemText primary={item.label} />
              {counts[item.id] > 0 && <Typography className="nav-count">{counts[item.id]}</Typography>}
            </ListItemButton>
          );
        })}
      </List>
      <Box className="sidebar-bottom">
        <Divider sx={{ mb: 2.1 }} />
        <Stack direction="row" spacing={1.25} alignItems="center">
          <Box className="storage-icon"><LightbulbOutlinedIcon sx={{ fontSize: 18 }} /></Box>
          <Box>
            <Typography variant="body2" sx={{ fontWeight: 600, lineHeight: 1.35 }}>Saved on this device</Typography>
            <Typography variant="caption" color="text.secondary">Private browser storage</Typography>
          </Box>
        </Stack>
      </Box>
    </Box>
  );

  return (
    <Box className="app-shell">
      {isMobile ? (
        <Drawer
          open={mobileNavOpen}
          onClose={() => setMobileNavOpen(false)}
          PaperProps={{ sx: { width: DRAWER_WIDTH, border: 0, borderRadius: '0 20px 20px 0' } }}
        >
          {sidebar}
        </Drawer>
      ) : (
        <Box component="aside" className="desktop-sidebar">{sidebar}</Box>
      )}

      <Box component="main" className="main-area">
        <Box className="topbar">
          {isMobile && (
            <IconButton onClick={() => setMobileNavOpen(true)} aria-label="Open navigation" sx={{ mr: 1 }}>
              <MenuRoundedIcon />
            </IconButton>
          )}
          <Box className="topbar-left">
            <Typography variant="body2" color="text.secondary">Your workspace</Typography>
            <Typography variant="body2" sx={{ color: 'text.primary', fontWeight: 600 }}> / {currentNav.label}</Typography>
          </Box>
          <Box sx={{ flex: 1 }} />
          <Button component="a" href="../" size="small" color="inherit" startIcon={<AppsRoundedIcon />} sx={{ mr: 1.5, whiteSpace: 'nowrap' }}>
            Design versions
          </Button>
          <Chip
            size="small"
            icon={<span className="save-dot" />}
            label="All changes saved"
            className="saved-chip"
          />
        </Box>

        <Box className="page-content">
          <Box className="page-heading">
            <Box>
              <Typography variant="h4" className="page-title">{titleByView[view]}</Typography>
              <Typography color="text.secondary" sx={{ mt: 0.75 }}>{subtitleByView[view]}</Typography>
            </Box>
            {view !== 'trash' && (
              <Button variant="contained" startIcon={<AddRoundedIcon />} onClick={openNewNote} className="heading-new-button">
                Create note
              </Button>
            )}
          </Box>

          {view === 'notes' && counts.pinned > 0 && (
            <Box className="section-label-row">
              <PushPinRoundedIcon sx={{ fontSize: 15, color: 'text.secondary' }} />
              <Typography variant="overline" color="text.secondary" sx={{ fontWeight: 700, letterSpacing: '0.1em' }}>PINNED NOTES</Typography>
            </Box>
          )}

          {visibleNotes.length === 0 ? (
            <Box className="empty-state">
              <Box className="empty-illustration">
                {view === 'trash' ? <DeleteOutlineRoundedIcon /> : view === 'archived' ? <Inventory2OutlinedIcon /> : <EditNoteRoundedIcon />}
              </Box>
              <Typography variant="h6" sx={{ mt: 2.5, fontWeight: 600 }}>
                {view === 'trash' ? 'Nothing in the trash' : view === 'archived' ? 'No archived notes yet' : view === 'pinned' ? 'No pinned notes' : 'Your notes start here'}
              </Typography>
              <Typography color="text.secondary" sx={{ mt: 0.75, maxWidth: 340, textAlign: 'center' }}>
                {view === 'trash'
                  ? 'Notes you delete will show up here.'
                  : view === 'archived'
                    ? 'Archive notes you want to keep but do not need right now.'
                    : view === 'pinned'
                      ? 'Pin important notes and they will be collected in one place.'
                      : 'Capture an idea, make a list, or write down whatever is on your mind.'}
              </Typography>
              {view === 'notes' && (
                <Button variant="outlined" startIcon={<AddRoundedIcon />} onClick={openNewNote} sx={{ mt: 2.5 }}>
                  Create your first note
                </Button>
              )}
              {view !== 'notes' && (
                <Button color="inherit" startIcon={<ArrowBackRoundedIcon />} onClick={() => setView('notes')} sx={{ mt: 2.5 }}>
                  Back to all notes
                </Button>
              )}
            </Box>
          ) : (
            <Box className="notes-grid">
              {visibleNotes.map((note) => (
                <Card
                  key={note.id}
                  className="note-card"
                  elevation={0}
                  sx={{ backgroundColor: note.color || '#fff' }}
                >
                  <CardActionArea
                    onClick={() => openEditNote(note)}
                    disabled={view === 'trash'}
                    className="note-card-action"
                  >
                    <CardContent className="note-card-content">
                      <Stack direction="row" alignItems="flex-start" justifyContent="space-between" spacing={1}>
                        <Typography className="note-title" variant="subtitle1">
                          {note.title || <span className="untitled-label">Untitled note</span>}
                        </Typography>
                        {note.pinned && !note.archived && !note.trashed && (
                          <PushPinRoundedIcon className="pinned-mark" sx={{ fontSize: 17 }} />
                        )}
                      </Stack>
                      <Typography component="div" className="note-preview">
                        {note.body || <span className="empty-note-label">No additional text</span>}
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                  <CardActions className="note-card-footer">
                    <Typography variant="caption" color="text.secondary" className="note-date">
                      {formatDate(note.updatedAt)}
                    </Typography>
                    <Box sx={{ flex: 1 }} />
                    {view === 'trash' ? (
                      <>
                        <Tooltip title="Restore note"><IconButton size="small" onClick={(event) => handleCardAction(event, () => restoreNote(note))}><RestoreFromTrashOutlinedIcon fontSize="small" /></IconButton></Tooltip>
                        <Tooltip title="Delete permanently"><IconButton size="small" color="error" onClick={(event) => handleCardAction(event, () => setDeleteTarget(note))}><DeleteForeverOutlinedIcon fontSize="small" /></IconButton></Tooltip>
                      </>
                    ) : view === 'archived' ? (
                      <>
                        <Tooltip title="Unarchive"><IconButton size="small" onClick={(event) => handleCardAction(event, () => updateNote(note.id, { archived: false }))}><UnarchiveOutlinedIcon fontSize="small" /></IconButton></Tooltip>
                        <Tooltip title="Move to trash"><IconButton size="small" onClick={(event) => handleCardAction(event, () => moveToTrash(note))}><DeleteOutlineRoundedIcon fontSize="small" /></IconButton></Tooltip>
                      </>
                    ) : (
                      <>
                        <Tooltip title={note.pinned ? 'Unpin' : 'Pin'}><IconButton size="small" onClick={(event) => handleCardAction(event, () => updateNote(note.id, { pinned: !note.pinned }))}><PushPinOutlinedIcon fontSize="small" /></IconButton></Tooltip>
                        <Tooltip title="Archive"><IconButton size="small" onClick={(event) => handleCardAction(event, () => { updateNote(note.id, { archived: true, pinned: false }); setSnackbar('Note archived'); })}><ArchiveOutlinedIcon fontSize="small" /></IconButton></Tooltip>
                        <Tooltip title="Move to trash"><IconButton size="small" onClick={(event) => handleCardAction(event, () => moveToTrash(note))}><DeleteOutlineRoundedIcon fontSize="small" /></IconButton></Tooltip>
                      </>
                    )}
                  </CardActions>
                </Card>
              ))}
            </Box>
          )}
          <Box className="page-bottom-space" />
        </Box>
      </Box>

      <Dialog
        open={editorOpen}
        onClose={() => setEditorOpen(false)}
        fullWidth
        maxWidth="sm"
        PaperProps={{ className: 'editor-dialog' }}
      >
        <DialogTitle className="editor-title-row">
          <Typography variant="h6">{editingId ? 'Edit note' : 'New note'}</Typography>
          <IconButton aria-label="Close editor" onClick={() => setEditorOpen(false)} size="small"><CloseRoundedIcon /></IconButton>
        </DialogTitle>
        <DialogContent className="editor-content">
          <TextField
            autoFocus
            fullWidth
            variant="standard"
            placeholder="Title"
            value={draftTitle}
            onChange={(event) => setDraftTitle(event.target.value)}
            InputProps={{ disableUnderline: true }}
            inputProps={{ maxLength: 140, 'aria-label': 'Note title' }}
            className="editor-title-input"
          />
          <TextField
            fullWidth
            multiline
            minRows={8}
            maxRows={18}
            variant="standard"
            placeholder="Start writing..."
            value={draftBody}
            onChange={(event) => setDraftBody(event.target.value)}
            InputProps={{ disableUnderline: true }}
            inputProps={{ 'aria-label': 'Note content' }}
            className="editor-body-input"
          />
          <Box className="color-picker-row">
            <Typography variant="caption" color="text.secondary" sx={{ mr: 1 }}>NOTE COLOR</Typography>
            <Stack direction="row" spacing={1}>
              {NOTE_COLORS.map((color) => (
                <Tooltip key={color.value} title={color.name}>
                  <IconButton
                    size="small"
                    aria-label={`${color.name} note color`}
                    onClick={() => setDraftColor(color.value)}
                    className={`color-swatch ${draftColor === color.value ? 'selected' : ''}`}
                    sx={{ backgroundColor: color.value, '&:hover': { backgroundColor: color.value } }}
                  >
                    {draftColor === color.value && <span className="swatch-check">✓</span>}
                  </IconButton>
                </Tooltip>
              ))}
            </Stack>
          </Box>
        </DialogContent>
        <DialogActions className="editor-actions">
          <Button color="inherit" onClick={() => setEditorOpen(false)}>Cancel</Button>
          <Button variant="contained" onClick={saveNote} disabled={!draftTitle.trim() && !draftBody.trim()}>
            Save note
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={Boolean(deleteTarget)} onClose={() => setDeleteTarget(null)} maxWidth="xs" fullWidth>
        <DialogTitle sx={{ pb: 1 }}>Delete this note permanently?</DialogTitle>
        <DialogContent>
          <Typography color="text.secondary" variant="body2">
            This note will be removed from this browser and cannot be restored.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5 }}>
          <Button color="inherit" onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button color="error" variant="contained" onClick={permanentlyDelete}>Delete permanently</Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={Boolean(snackbar)}
        autoHideDuration={2600}
        onClose={() => setSnackbar('')}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert onClose={() => setSnackbar('')} severity="success" variant="filled" sx={{ borderRadius: 3, boxShadow: '0 8px 30px rgba(23,30,58,.18)' }}>
          {snackbar}
        </Alert>
      </Snackbar>
    </Box>
  );
}

export default App;
