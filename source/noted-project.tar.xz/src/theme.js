import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: { main: '#5267c7', dark: '#4054af', light: '#e9edff' },
    background: { default: '#f7f8fc', paper: '#ffffff' },
    text: { primary: '#202334', secondary: '#6f7485' },
    divider: '#e8eaf1',
    error: { main: '#c44e5a' },
  },
  shape: { borderRadius: 16 },
  typography: {
    fontFamily: 'Roboto, Arial, sans-serif',
    h4: { fontWeight: 600, letterSpacing: '-0.035em' },
    h5: { fontWeight: 600, letterSpacing: '-0.025em' },
    h6: { fontWeight: 600, letterSpacing: '-0.015em' },
    button: { textTransform: 'none', fontWeight: 600, letterSpacing: 0 },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: { borderRadius: 12, minHeight: 42, boxShadow: 'none' },
        contained: { boxShadow: 'none', '&:hover': { boxShadow: 'none' } },
      },
    },
    MuiIconButton: { styleOverrides: { root: { borderRadius: 11 } } },
    MuiPaper: { styleOverrides: { rounded: { borderRadius: 18 } } },
    MuiDialog: { styleOverrides: { paper: { borderRadius: 22 } } },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          borderRadius: 13,
          backgroundColor: '#fff',
          '& fieldset': { borderColor: '#e5e7ef' },
          '&:hover fieldset': { borderColor: '#b9bfd4' },
        },
      },
    },
  },
});

export default theme;
