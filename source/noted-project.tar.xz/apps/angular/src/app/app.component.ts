import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';

interface Note {
  id: string;
  title: string;
  body: string;
  color: string;
  pinned: boolean;
  archived: boolean;
  trashed: boolean;
  createdAt: string;
  updatedAt: string;
  trashedAt?: string | null;
}

type ViewName = 'notes' | 'pinned' | 'archived' | 'trash';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatButtonModule, MatCardModule, MatFormFieldModule,
    MatIconModule, MatInputModule, MatListModule, MatSidenavModule, MatToolbarModule,
  ],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  private readonly storageKey = 'noted.angular-material.notes.v1';
  readonly navItems: { id: ViewName; label: string; icon: string }[] = [
    { id: 'notes', label: 'All notes', icon: 'description' },
    { id: 'pinned', label: 'Pinned', icon: 'push_pin' },
    { id: 'archived', label: 'Archive', icon: 'archive' },
    { id: 'trash', label: 'Trash', icon: 'delete' },
  ];
  readonly colors = [
    { name: 'Default', value: '#ffffff' },
    { name: 'Cream', value: '#fff8e8' },
    { name: 'Rose', value: '#fff0f1' },
    { name: 'Sage', value: '#edf6ef' },
    { name: 'Sky', value: '#edf5ff' },
    { name: 'Lilac', value: '#f3efff' },
  ];
  notes: Note[] = this.readNotes();
  view: ViewName = 'notes';
  editorOpen = false;
  deleteDialogOpen = false;
  editingId: string | null = null;
  deleteTarget: string | null = null;
  draftTitle = '';
  draftBody = '';
  draftColor = this.colors[0].value;
  message = '';
  private messageTimer?: ReturnType<typeof setTimeout>;

  get currentNavLabel(): string {
    return this.navItems.find((item) => item.id === this.view)?.label ?? 'All notes';
  }

  get visibleNotes(): Note[] {
    const result = this.notes.filter((note) => {
      if (this.view === 'pinned') return note.pinned && !note.archived && !note.trashed;
      if (this.view === 'archived') return note.archived && !note.trashed;
      if (this.view === 'trash') return note.trashed;
      return !note.archived && !note.trashed;
    });
    return [...result].sort((a, b) => this.view === 'trash'
      ? new Date(b.trashedAt || b.updatedAt).getTime() - new Date(a.trashedAt || a.updatedAt).getTime()
      : (this.view === 'notes' && a.pinned !== b.pinned
        ? (a.pinned ? -1 : 1)
        : new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()));
  }

  count(id: ViewName): number {
    if (id === 'notes') return this.notes.filter((note) => !note.archived && !note.trashed).length;
    if (id === 'pinned') return this.notes.filter((note) => note.pinned && !note.archived && !note.trashed).length;
    if (id === 'archived') return this.notes.filter((note) => note.archived && !note.trashed).length;
    return this.notes.filter((note) => note.trashed).length;
  }

  private readNotes(): Note[] {
    try {
      const raw = localStorage.getItem(this.storageKey);
      const parsed: unknown = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed as Note[] : [];
    } catch { return []; }
  }

  private persist(): void {
    try { localStorage.setItem(this.storageKey, JSON.stringify(this.notes)); }
    catch { this.showMessage('Browser storage is full. Some changes may not be saved.'); }
  }

  selectView(view: ViewName): void { this.view = view; }

  openNewNote(): void {
    this.editingId = null;
    this.draftTitle = '';
    this.draftBody = '';
    this.draftColor = this.colors[0].value;
    this.editorOpen = true;
  }

  editNote(note: Note): void {
    if (this.view === 'trash') return;
    this.editingId = note.id;
    this.draftTitle = note.title;
    this.draftBody = note.body;
    this.draftColor = note.color || this.colors[0].value;
    this.editorOpen = true;
  }

  saveNote(): void {
    const title = this.draftTitle.trim();
    const body = this.draftBody.trim();
    if (!title && !body) { this.editorOpen = false; return; }
    const now = new Date().toISOString();
    if (this.editingId) {
      this.notes = this.notes.map((note) => note.id === this.editingId
        ? { ...note, title, body, color: this.draftColor, updatedAt: now }
        : note);
      this.showMessage('Note updated');
    } else {
      this.notes.unshift({
        id: globalThis.crypto?.randomUUID?.() ?? `note-${Date.now()}-${Math.random()}`,
        title, body, color: this.draftColor, pinned: false, archived: false, trashed: false,
        createdAt: now, updatedAt: now,
      });
      this.showMessage('Note created');
    }
    this.persist();
    this.editorOpen = false;
    this.view = 'notes';
  }

  updateNote(id: string, updates: Partial<Note>): void {
    const now = new Date().toISOString();
    this.notes = this.notes.map((note) => note.id === id ? { ...note, ...updates, updatedAt: now } : note);
    this.persist();
  }

  togglePin(note: Note): void { this.updateNote(note.id, { pinned: !note.pinned }); }
  archive(note: Note): void { this.updateNote(note.id, { archived: true, pinned: false }); this.showMessage('Note archived'); }
  unarchive(note: Note): void { this.updateNote(note.id, { archived: false }); }
  trash(note: Note): void { this.updateNote(note.id, { trashed: true, trashedAt: new Date().toISOString(), archived: false }); this.showMessage('Moved to trash'); }
  restore(note: Note): void { this.updateNote(note.id, { trashed: false, trashedAt: null }); this.showMessage('Note restored'); }

  askDelete(note: Note): void { this.deleteTarget = note.id; this.deleteDialogOpen = true; }
  permanentlyDelete(): void {
    if (!this.deleteTarget) return;
    this.notes = this.notes.filter((note) => note.id !== this.deleteTarget);
    this.deleteTarget = null;
    this.deleteDialogOpen = false;
    this.persist();
    this.showMessage('Note permanently deleted');
  }

  formatDate(value: string): string {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return 'Recently edited';
    return date.toDateString() === new Date().toDateString()
      ? `Edited ${date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}`
      : `Edited ${date.toLocaleDateString([], { month: 'short', day: 'numeric' })}`;
  }

  showMessage(value: string): void {
    this.message = value;
    if (this.messageTimer) clearTimeout(this.messageTimer);
    this.messageTimer = setTimeout(() => this.message = '', 2600);
  }

  trackById(_index: number, note: Note): string { return note.id; }
}
