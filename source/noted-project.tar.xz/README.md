# Noted — Three Material design implementations

Noted is a responsive note-taking app implemented three ways so the component-library versions can be compared side by side:

- **MUI** — React, using the official `@mui/material` and `@mui/icons-material` packages.
- **Angular Material** — a standalone Angular app using the official `@angular/material` component library and its Material 3 Azure Blue theme.
- **Material 3** — a standalone web app using Google's official `@material/web` web components and Material 3 design tokens.

## GitHub Pages

The repository workflow builds all three apps and publishes them together:

- `/Noted/` — design selector
- `/Noted/mui/` — MUI version
- `/Noted/angular/` — Angular Material version
- `/Noted/material3/` — Google Material 3 version

In GitHub, open **Settings → Pages** and select **GitHub Actions** as the source. The `.github/workflows/deploy.yml` workflow then builds and deploys the site on every push to `main` (or when run manually).

## Run the MUI and Material 3 apps locally

Requires Node.js 22 or newer.

```bash
npm install
npm run dev
```

The Vite development server serves the design selector, `/mui/`, and `/material3/` routes.

## Run the Angular Material app locally

Requires Node.js 22.22.3+ or 24.15.0+ and TypeScript 6.0.x, matching the current Angular 22 compatibility table.

```bash
cd apps/angular
npm install
npm start
```

## Browser storage

Each design implementation saves notes in the current browser using its own `localStorage` key. Notes are private to that browser and version; they do not sync between devices or share data between implementations. Clearing the site's browser storage removes those notes.

## Official component library notes

The Material 3 version uses Google's `@material/web` package (2.5.0). The upstream project currently labels Material Web as being in maintenance mode pending new maintainers; this version therefore uses the released official package rather than a third-party replacement.
